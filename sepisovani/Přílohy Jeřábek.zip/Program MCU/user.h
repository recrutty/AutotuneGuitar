#ifndef USER_H
#define	USER_H

void InitApp();
#endif	/* USER_H */

