#ifndef STRINGINFO_H
#define	STRINGINFO_H


#endif	/* STRINGINFO_H */

